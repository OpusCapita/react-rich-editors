modules = {

    'react-rich-editors' {
        resource url: [plugin: 'jcatalog-react-rich-editors', file: 'js/grails-index.js', nominify: true]
    }
}