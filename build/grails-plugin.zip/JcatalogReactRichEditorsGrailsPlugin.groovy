class JcatalogReactRichEditorsGrailsPlugin {
    def groupId = "com.jcatalog.grailsplugins"
    def version = "0.0.2-SNAPSHOT"
    def grailsVersion = "2.1 > *"

    def title = "Auto-generated for jcatalog-react-rich-editors"
    def author = "Kirill Volkovich"
    def authorEmail = "volkovich@scand.com"
    def description = "Start write new project with no effort."

    def documentation = "http://buildserver.jcatalog.com/generated-docs/${groupId}/com.jcatalog.grailsplugins/${version}/"

    def organization = [name: "jCatalog", url: "http://www.jcatalog.com/"]
    def developers = [[name: "Kirill Volkovich", email: "volkovich@scand.com"]]
}
